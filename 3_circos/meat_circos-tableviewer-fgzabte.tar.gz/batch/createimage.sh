PERL=/home/martink/bin/perl
TABLEVIEWER_DIR=/home/martink/work/circos/svn/tools/tableviewer
CIRCOS_DIR=/home/martink/work/circos/svn-tags/circos-tableviewer/
WORKING_DIR=/home/martink/www/htdocs/tableviewer/tmp/fgzabte
cd /home/martink/www/htdocs/tableviewer/tmp/fgzabte
$PERL $TABLEVIEWER_DIR/bin/parse-table -conf etc/parse-table.conf -file uploads/table.txt -segment_order=col_major,size_desc -placement_order=row,col -interpolate_type count -col_color_row -use_col_color_row -color_source col -transparency 2 -fade_transparency 0 -ribbon_layer_order=size_asc > data/parsed.txt
cat data/parsed.txt | $TABLEVIEWER_DIR/bin/make-conf -dir data
$PERL $CIRCOS_DIR/bin/circos -param random_string=fgzabte -conf etc/circos.conf
cd /home/martink/www/htdocs/tableviewer/tmp/fgzabte; /home/martink/bin/perl /home/martink/work/circos/svn-tags/circos-tableviewer//bin/circos -param random_string=fgzabte -conf /home/martink/www/htdocs/tableviewer/tmp/fgzabte/etc/circos.conf 2>&1 > /home/martink/www/htdocs/tableviewer/tmp/fgzabte/results/report.txt
tar cvfz circos-tableviewer-fgzabte.tar.gz *
